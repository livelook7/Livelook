# Livelook — Next.js + Tailwind demo

Koyu temalı tişört mağazası demo (Next.js). Deploy: Vercel recommended.

Run locally:
```
npm install
npm run dev
```
