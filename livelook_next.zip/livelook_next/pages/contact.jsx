import Header from '../components/Header'
export default function Contact(){ return (<div className="min-h-screen bg-bg text-white"><Header /><main className="max-w-3xl mx-auto p-6"><h1 className="text-2xl font-bold">İletişim</h1><p className="mt-3 text-gray-300">Bize ulaş: info@livelook.example</p></main></div>) }
